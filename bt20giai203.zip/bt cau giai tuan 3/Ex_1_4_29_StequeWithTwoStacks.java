import java.util.*;

public class Ex_1_4_29_StequeWithTwoStacks<Item> {
    private final Deque<Item> left = new ArrayDeque<>();
    private final Deque<Item> right = new ArrayDeque<>();

    public boolean isEmpty() {
        return left.isEmpty() && right.isEmpty();
    }

    public int size() {
        return left.size() + right.size();
    }

    public void push(Item item) {
        left.push(item);
    }

    public void enqueue(Item item) {
        right.push(item);
    }

    public Item pop() {
        if (isEmpty()) throw new NoSuchElementException("Steque is empty");

        if (left.isEmpty()) {
            while (!right.isEmpty()) {
                left.push(right.pop());
            }
        }
        return left.pop();
    }

    public static void main(String[] args) {
        Ex_1_4_29_StequeWithTwoStacks<Integer> s =
                new Ex_1_4_29_StequeWithTwoStacks<>();

        s.enqueue(1);
        s.enqueue(2);
        s.push(3);
        s.push(4);

        System.out.println(s.pop());
        System.out.println(s.pop());
        System.out.println(s.pop());
        System.out.println(s.pop());
    }
}
