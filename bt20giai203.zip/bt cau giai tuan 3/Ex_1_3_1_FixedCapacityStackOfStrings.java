public class Ex_1_3_1_FixedCapacityStackOfStrings {
    private final String[] a;
    private int n = 0;

    public Ex_1_3_1_FixedCapacityStackOfStrings(int capacity) {
        a = new String[capacity];
    }

    public boolean isEmpty() {
        return n == 0;
    }

    public boolean isFull() {
        return n == a.length;
    }

    public int size() {
        return n;
    }

    public void push(String item) {
        if (isFull()) throw new IllegalStateException("Stack is full");
        a[n++] = item;
    }

    public String pop() {
        if (isEmpty()) throw new IllegalStateException("Stack is empty");
        String item = a[--n];
        a[n] = null;
        return item;
    }

    public static void main(String[] args) {
        Ex_1_3_1_FixedCapacityStackOfStrings stack =
                new Ex_1_3_1_FixedCapacityStackOfStrings(3);

        stack.push("A");
        stack.push("B");
        stack.push("C");

        System.out.println("isFull = " + stack.isFull());
        System.out.println("pop = " + stack.pop());
        System.out.println("isFull = " + stack.isFull());
    }
}
