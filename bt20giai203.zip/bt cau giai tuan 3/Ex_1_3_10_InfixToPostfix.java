import java.util.*;

public class Ex_1_3_10_InfixToPostfix {
    private static int precedence(String op) {
        if (op.equals("+") || op.equals("-")) return 1;
        if (op.equals("*") || op.equals("/")) return 2;
        if (op.equals("^")) return 3;
        return 0;
    }

    private static boolean isOperator(String s) {
        return s.equals("+") || s.equals("-") ||
               s.equals("*") || s.equals("/") || s.equals("^");
    }

    public static String convert(String infix) {
        Deque<String> ops = new ArrayDeque<>();
        StringBuilder out = new StringBuilder();

        StringTokenizer st = new StringTokenizer(infix);
        while (st.hasMoreTokens()) {
            String token = st.nextToken();

            if (token.equals("(")) {
                ops.push(token);
            } else if (token.equals(")")) {
                while (!ops.isEmpty() && !ops.peek().equals("(")) {
                    out.append(ops.pop()).append(' ');
                }
                if (ops.isEmpty()) throw new IllegalArgumentException("Mismatched parentheses");
                ops.pop();
            } else if (isOperator(token)) {
                while (!ops.isEmpty() && isOperator(ops.peek())
                        && precedence(ops.peek()) >= precedence(token)) {
                    out.append(ops.pop()).append(' ');
                }
                ops.push(token);
            } else {
                out.append(token).append(' ');
            }
        }

        while (!ops.isEmpty()) {
            if (ops.peek().equals("(")) throw new IllegalArgumentException("Mismatched parentheses");
            out.append(ops.pop()).append(' ');
        }

        return out.toString().trim();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.useDelimiter("\\A").hasNext() ? sc.next() : "";
        System.out.println(convert(input));
    }
}
