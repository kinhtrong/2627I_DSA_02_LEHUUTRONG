import java.util.*;

public class Ex_1_3_9_InfixParentheses {
    private static boolean isOperator(String token) {
        return token.equals("+") || token.equals("-") ||
               token.equals("*") || token.equals("/");
    }

    public static String convert(String input) {
        Deque<String> operands = new ArrayDeque<>();
        Deque<String> operators = new ArrayDeque<>();

        StringTokenizer tokenizer = new StringTokenizer(input);
        while (tokenizer.hasMoreTokens()) {
            String token = tokenizer.nextToken();

            if (token.equals("(")) {
                continue;
            } else if (isOperator(token)) {
                operators.push(token);
            } else if (token.equals(")")) {
                if (operands.size() < 2 || operators.isEmpty()) {
                    throw new IllegalArgumentException("Invalid expression");
                }
                String right = operands.pop();
                String left = operands.pop();
                String op = operators.pop();
                operands.push("( " + left + " " + op + " " + right + " )");
            } else {
                operands.push(token);
            }
        }

        if (operands.size() != 1 || !operators.isEmpty()) {
            throw new IllegalArgumentException("Invalid expression");
        }
        return operands.pop();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.useDelimiter("\\A").hasNext() ? sc.next() : "";

        System.out.println(convert(input).trim());
    }
}
