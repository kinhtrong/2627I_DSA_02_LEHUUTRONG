import java.util.*;

public class Ex_1_4_30_DequeWithStackAndSteque<Item> {
    /*
     * Dùng:
     *   - Stack left: đầu trái của deque.
     *   - Steque right: dùng các phép push/pop của steque như một stack
     *     để giữ phần bên phải.
     *
     * Khi một phía rỗng, chuyển toàn bộ phần tử từ phía còn lại sang.
     * Việc chuyển được thực hiện theo kiểu đảo thứ tự, nên phần tử cần
     * lấy ở đầu đối diện sẽ trở thành đỉnh stack. Chi phí chuyển được
     * phân bổ theo kiểu amortized.
     */

    private final Deque<Item> left = new ArrayDeque<>();
    private final Ex_1_4_29_StequeWithTwoStacks<Item> right =
            new Ex_1_4_29_StequeWithTwoStacks<>();

    public boolean isEmpty() {
        return left.isEmpty() && right.isEmpty();
    }

    public int size() {
        return left.size() + right.size();
    }

    public void pushLeft(Item item) {
        left.push(item);
    }

    public void pushRight(Item item) {
        right.push(item);
    }

    public Item popLeft() {
        if (left.isEmpty()) {
            moveRightToLeft();
        }
        if (left.isEmpty()) throw new NoSuchElementException("Deque is empty");
        return left.pop();
    }

    public Item popRight() {
        if (right.isEmpty()) {
            moveLeftToRight();
        }
        if (right.isEmpty()) throw new NoSuchElementException("Deque is empty");
        return right.pop();
    }

    private void moveRightToLeft() {
        while (!right.isEmpty()) {
            left.push(right.pop());
        }
    }

    private void moveLeftToRight() {
        while (!left.isEmpty()) {
            right.push(left.pop());
        }
    }

    public static void main(String[] args) {
        Ex_1_4_30_DequeWithStackAndSteque<Integer> d =
                new Ex_1_4_30_DequeWithStackAndSteque<>();

        d.pushLeft(2);
        d.pushLeft(1);
        d.pushRight(3);
        d.pushRight(4);

        System.out.println(d.popLeft());   // 1
        System.out.println(d.popRight());  // 4
        System.out.println(d.popLeft());   // 2
        System.out.println(d.popRight());  // 3
    }
}
