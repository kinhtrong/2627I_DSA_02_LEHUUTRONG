import java.util.*;

public class Ex_1_4_27_QueueWithTwoStacks<Item> {
    private final Deque<Item> in = new ArrayDeque<>();
    private final Deque<Item> out = new ArrayDeque<>();

    public boolean isEmpty() {
        return in.isEmpty() && out.isEmpty();
    }

    public int size() {
        return in.size() + out.size();
    }

    public void enqueue(Item item) {
        in.push(item);
    }

    private void moveIfNeeded() {
        if (out.isEmpty()) {
            while (!in.isEmpty()) {
                out.push(in.pop());
            }
        }
    }

    public Item dequeue() {
        moveIfNeeded();
        if (out.isEmpty()) throw new NoSuchElementException("Queue is empty");
        return out.pop();
    }

    public Item peek() {
        moveIfNeeded();
        if (out.isEmpty()) throw new NoSuchElementException("Queue is empty");
        return out.peek();
    }

    public static void main(String[] args) {
        Ex_1_4_27_QueueWithTwoStacks<Integer> q =
                new Ex_1_4_27_QueueWithTwoStacks<>();

        q.enqueue(1);
        q.enqueue(2);
        q.enqueue(3);

        System.out.println(q.dequeue());
        System.out.println(q.dequeue());

        q.enqueue(4);
        System.out.println(q.dequeue());
        System.out.println(q.dequeue());
    }
}
