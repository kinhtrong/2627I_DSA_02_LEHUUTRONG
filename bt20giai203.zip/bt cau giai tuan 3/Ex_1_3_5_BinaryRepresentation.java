import java.util.*;

public class Ex_1_3_5_BinaryRepresentation {
    public static void main(String[] args) {
        int n = (args.length > 0) ? Integer.parseInt(args[0]) : 50;

        if (n == 0) {
            System.out.println("0");
            return;
        }

        Deque<Integer> stack = new ArrayDeque<>();
        while (n > 0) {
            stack.push(n % 2);
            n /= 2;
        }

        for (int d : stack) {
            System.out.print(d);
        }
        System.out.println();
    }
}
