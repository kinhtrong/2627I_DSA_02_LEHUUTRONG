import java.util.*;

public class Ex_1_4_31_DequeWithThreeStacks<Item> {
    private final Deque<Item> left = new ArrayDeque<>();
    private final Deque<Item> right = new ArrayDeque<>();
    private final Deque<Item> buffer = new ArrayDeque<>();

    public boolean isEmpty() {
        return left.isEmpty() && right.isEmpty();
    }

    public int size() {
        return left.size() + right.size();
    }

    public void pushLeft(Item item) {
        left.push(item);
    }

    public void pushRight(Item item) {
        right.push(item);
    }

    public Item popLeft() {
        if (left.isEmpty()) rebalanceLeft();
        if (left.isEmpty()) throw new NoSuchElementException("Deque is empty");
        return left.pop();
    }

    public Item popRight() {
        if (right.isEmpty()) rebalanceRight();
        if (right.isEmpty()) throw new NoSuchElementException("Deque is empty");
        return right.pop();
    }

    private void rebalanceLeft() {
        int move = right.size() / 2;
        if (move == 0) move = right.size();

        for (int i = 0; i < move; i++) {
            buffer.push(right.pop());
        }

        while (!right.isEmpty()) {
            left.push(right.pop());
        }

        while (!buffer.isEmpty()) {
            right.push(buffer.pop());
        }
    }

    private void rebalanceRight() {
        int move = left.size() / 2;
        if (move == 0) move = left.size();

        for (int i = 0; i < move; i++) {
            buffer.push(left.pop());
        }

        while (!left.isEmpty()) {
            right.push(left.pop());
        }

        while (!buffer.isEmpty()) {
            left.push(buffer.pop());
        }
    }

    public static void main(String[] args) {
        Ex_1_4_31_DequeWithThreeStacks<Integer> d =
                new Ex_1_4_31_DequeWithThreeStacks<>();

        d.pushLeft(2);
        d.pushLeft(1);
        d.pushRight(3);
        d.pushRight(4);

        System.out.println(d.popLeft());
        System.out.println(d.popRight());
        System.out.println(d.popLeft());
        System.out.println(d.popRight());
    }
}
