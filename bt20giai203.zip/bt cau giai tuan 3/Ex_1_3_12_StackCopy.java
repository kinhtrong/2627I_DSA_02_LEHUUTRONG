import java.util.*;

public class Ex_1_3_12_StackCopy {
    public static Stack<String> copy(Stack<String> original) {
        Stack<String> copy = new Stack<>();

        // Iterator của Stack đi từ phần tử trên cùng xuống dưới cùng.
        // Dùng một stack tạm để giữ đúng thứ tự của bản sao.
        Stack<String> temp = new Stack<>();
        for (String item : original) {
            temp.push(item);
        }
        for (String item : temp) {
            copy.push(item);
        }

        return copy;
    }

    public static void main(String[] args) {
        Stack<String> stack = new Stack<>();
        stack.push("A");
        stack.push("B");
        stack.push("C");

        Stack<String> copy = copy(stack);

        System.out.println("Original: " + stack);
        System.out.println("Copy    : " + copy);
    }
}
