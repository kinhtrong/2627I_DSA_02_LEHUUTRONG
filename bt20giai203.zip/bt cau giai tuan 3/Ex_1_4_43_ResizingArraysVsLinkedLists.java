import java.util.*;

public class Ex_1_4_43_ResizingArraysVsLinkedLists {

    private static class ArrayStack {
        private int[] a = new int[1];
        private int n = 0;

        void push(int x) {
            if (n == a.length) a = Arrays.copyOf(a, a.length * 2);
            a[n++] = x;
        }

        int pop() {
            if (n == 0) throw new NoSuchElementException();
            int x = a[--n];
            a[n] = 0;
            if (n > 0 && n == a.length / 4) {
                a = Arrays.copyOf(a, a.length / 2);
            }
            return x;
        }
    }

    private static class LinkedStack {
        private Node first;

        private static class Node {
            int item;
            Node next;

            Node(int item, Node next) {
                this.item = item;
                this.next = next;
            }
        }

        void push(int x) {
            first = new Node(x, first);
        }

        int pop() {
            if (first == null) throw new NoSuchElementException();
            int x = first.item;
            first = first.next;
            return x;
        }
    }

    private static double timeArrayStack(int n, int trials) {
        long start = System.nanoTime();

        for (int t = 0; t < trials; t++) {
            ArrayStack stack = new ArrayStack();
            for (int i = 0; i < n; i++) stack.push(i);
            for (int i = 0; i < n; i++) stack.pop();
        }

        return (System.nanoTime() - start) / 1e9;
    }

    private static double timeLinkedStack(int n, int trials) {
        long start = System.nanoTime();

        for (int t = 0; t < trials; t++) {
            LinkedStack stack = new LinkedStack();
            for (int i = 0; i < n; i++) stack.push(i);
            for (int i = 0; i < n; i++) stack.pop();
        }

        return (System.nanoTime() - start) / 1e9;
    }

    public static void main(String[] args) {
        int startN = args.length > 0 ? Integer.parseInt(args[0]) : 100_000;
        int trials = args.length > 1 ? Integer.parseInt(args[1]) : 3;
        int maxN = args.length > 2 ? Integer.parseInt(args[2]) : 1_600_000;

        System.out.println("N\tArray(s)\tLinkedList(s)\tLinked/Array");

        for (int n = startN; n <= maxN; n *= 2) {
            // Warm-up
            timeArrayStack(Math.min(n, 10_000), 1);
            timeLinkedStack(Math.min(n, 10_000), 1);

            double arrayTime = timeArrayStack(n, trials);
            double linkedTime = timeLinkedStack(n, trials);

            System.out.printf(Locale.US, "%d\t%.6f\t%.6f\t%.3f%n",
                    n, arrayTime, linkedTime, linkedTime / arrayTime);
        }
    }
}
