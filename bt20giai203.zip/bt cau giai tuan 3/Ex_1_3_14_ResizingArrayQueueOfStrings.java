import java.util.*;

public class Ex_1_3_14_ResizingArrayQueueOfStrings {
    private String[] a;
    private int first = 0;
    private int last = 0;
    private int size = 0;

    public Ex_1_3_14_ResizingArrayQueueOfStrings(int capacity) {
        if (capacity < 1) capacity = 1;
        a = new String[capacity];
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    private void resize(int capacity) {
        String[] temp = new String[capacity];
        for (int i = 0; i < size; i++) {
            temp[i] = a[(first + i) % a.length];
        }
        a = temp;
        first = 0;
        last = size;
    }

    public void enqueue(String item) {
        if (size == a.length) resize(2 * a.length);
        a[last] = item;
        last = (last + 1) % a.length;
        size++;
    }

    public String dequeue() {
        if (isEmpty()) throw new NoSuchElementException("Queue is empty");

        String item = a[first];
        a[first] = null;
        first = (first + 1) % a.length;
        size--;

        if (size > 0 && size == a.length / 4) {
            resize(a.length / 2);
        }
        return item;
    }

    public static void main(String[] args) {
        Ex_1_3_14_ResizingArrayQueueOfStrings q =
                new Ex_1_3_14_ResizingArrayQueueOfStrings(2);

        q.enqueue("A");
        q.enqueue("B");
        q.enqueue("C");
        q.enqueue("D");

        System.out.println(q.dequeue());
        System.out.println(q.dequeue());
        System.out.println("size = " + q.size());
    }
}
