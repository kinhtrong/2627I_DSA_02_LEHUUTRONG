BT CẤU GIẢI TUẦN 3
===================

Các file:
- Ex_1_3_1_FixedCapacityStackOfStrings.java
- Ex_1_3_3_StackOutput.java
- Ex_1_3_4_Parentheses.java
- Ex_1_3_5_BinaryRepresentation.java
- Ex_1_3_6_ReverseQueue.java
- Ex_1_3_7_StackPeek.java
- Ex_1_3_9_InfixParentheses.java
- Ex_1_3_10_InfixToPostfix.java
- Ex_1_3_11_EvaluatePostfix.java
- Ex_1_3_12_StackCopy.java
- Ex_1_3_13_QueueOutput.java
- Ex_1_3_14_ResizingArrayQueueOfStrings.java
- Ex_1_3_15_KthFromRecent.java
- Ex_1_2_29_ColorConversion.java
- Ex_1_4_27_QueueWithTwoStacks.java
- Ex_1_4_28_StackWithQueue.java
- Ex_1_4_29_StequeWithTwoStacks.java
- Ex_1_4_30_DequeWithStackAndSteque.java
- Ex_1_4_31_DequeWithThreeStacks.java
- Ex_1_4_32_AmortizedAnalysis.java
- Ex_1_4_43_ResizingArraysVsLinkedLists.java

Các bài 1.4.27-1.4.32 là các bài creative problems của Algorithms 4th.
1.4.32 là bài chứng minh amortized analysis nên file Java chủ yếu ghi ý tưởng/chứng minh.
