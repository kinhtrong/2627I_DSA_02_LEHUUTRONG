import java.util.*;

public class Ex_1_4_28_StackWithQueue<Item> {
    private final Queue<Item> q = new ArrayDeque<>();

    public boolean isEmpty() {
        return q.isEmpty();
    }

    public int size() {
        return q.size();
    }

    public void push(Item item) {
        q.add(item);
    }

    public Item pop() {
        if (q.isEmpty()) throw new NoSuchElementException("Stack is empty");

        int n = q.size();
        for (int i = 0; i < n - 1; i++) {
            q.add(q.remove());
        }
        return q.remove();
    }

    public Item peek() {
        if (q.isEmpty()) throw new NoSuchElementException("Stack is empty");

        int n = q.size();
        for (int i = 0; i < n - 1; i++) {
            q.add(q.remove());
        }
        Item result = q.remove();
        q.add(result);
        return result;
    }

    public static void main(String[] args) {
        Ex_1_4_28_StackWithQueue<Integer> stack =
                new Ex_1_4_28_StackWithQueue<>();

        stack.push(10);
        stack.push(20);
        stack.push(30);

        System.out.println(stack.pop());
        System.out.println(stack.pop());
        System.out.println(stack.pop());
    }
}
