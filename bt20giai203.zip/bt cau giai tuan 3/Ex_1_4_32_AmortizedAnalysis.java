public class Ex_1_4_32_AmortizedAnalysis {
    /*
     * Ý tưởng chứng minh:
     *
     * Với resizing array stack, mỗi lần mảng đầy thì kích thước tăng gấp đôi.
     * Các lần resize khi push có chi phí sao chép:
     * 1 + 2 + 4 + 8 + ... < 2M.
     *
     * Nếu có shrinking khi mảng còn 1/4 đầy, các lần sao chép do shrink
     * cũng tạo thành một cấp số nhân và tổng chi phí là O(M).
     *
     * M thao tác push/pop thông thường tốn O(M), còn tổng chi phí resize
     * cũng O(M). Vì vậy tổng số array accesses của bất kỳ chuỗi M thao tác
     * là O(M), hay chi phí trung bình (amortized) là O(1) mỗi thao tác.
     */
    public static void main(String[] args) {
        System.out.println("Exercise 1.4.32");
        System.out.println("Tong so array accesses cua M thao tac la O(M).");
        System.out.println("Chi phi amortized cho moi thao tac la O(1).");
    }
}
