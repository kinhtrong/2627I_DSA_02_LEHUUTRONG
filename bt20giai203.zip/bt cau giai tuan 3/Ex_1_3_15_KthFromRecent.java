import java.util.*;

public class Ex_1_3_15_KthFromRecent {
    public static String kthFromRecent(int k, String[] input) {
        if (k <= 0) throw new IllegalArgumentException("k must be positive");

        Queue<String> q = new ArrayDeque<>();
        for (String s : input) {
            q.add(s);
            if (q.size() > k) q.remove();
        }

        if (q.size() < k) throw new IllegalArgumentException("Not enough strings");
        return q.peek();
    }

    public static void main(String[] args) {
        if (args.length == 0) {
            System.err.println("Usage: java Ex_1_3_15_KthFromRecent k < input.txt");
            return;
        }

        int k = Integer.parseInt(args[0]);
        Scanner sc = new Scanner(System.in);
        Queue<String> q = new ArrayDeque<>();

        while (sc.hasNext()) {
            q.add(sc.next());
            if (q.size() > k) q.remove();
        }

        System.out.println(q.peek());
    }
}
