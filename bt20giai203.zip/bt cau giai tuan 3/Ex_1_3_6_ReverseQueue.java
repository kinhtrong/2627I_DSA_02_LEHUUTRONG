import java.util.*;

public class Ex_1_3_6_ReverseQueue {
    public static void main(String[] args) {
        Queue<String> q = new ArrayDeque<>();
        q.add("A");
        q.add("B");
        q.add("C");
        q.add("D");

        Deque<String> stack = new ArrayDeque<>();
        while (!q.isEmpty()) {
            stack.push(q.remove());
        }
        while (!stack.isEmpty()) {
            q.add(stack.pop());
        }

        System.out.println(q);
    }
}
