import java.util.*;

public class Ex_1_3_3_StackOutput {
    private static boolean isPossible(int[] output) {
        Deque<Integer> stack = new ArrayDeque<>();
        int nextPush = 0;

        for (int wanted : output) {
            while ((stack.isEmpty() || stack.peek() != wanted) && nextPush <= 9) {
                stack.push(nextPush++);
            }

            if (stack.isEmpty() || stack.peek() != wanted) {
                return false;
            }

            stack.pop();
        }
        return true;
    }

    public static void main(String[] args) {
        int[][] tests = {
            {4,3,2,1,0,9,8,7,6,5},
            {4,6,8,7,5,3,2,9,0,1},
            {2,5,6,7,4,8,9,3,1,0},
            {4,3,2,1,0,5,6,7,8,9},
            {1,2,3,4,5,6,9,8,7,0},
            {0,4,6,5,3,8,1,7,2,9},
            {1,4,7,9,8,6,5,3,0,2},
            {2,1,4,3,6,5,8,7,9,0}
        };

        char c = 'a';
        for (int[] test : tests) {
            System.out.println(c++ + ": " + isPossible(test));
        }
    }
}
