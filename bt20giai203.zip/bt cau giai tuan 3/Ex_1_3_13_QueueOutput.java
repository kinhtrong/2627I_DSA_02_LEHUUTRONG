import java.util.*;

public class Ex_1_3_13_QueueOutput {
    private static boolean isPossible(int[] output) {
        Queue<Integer> q = new ArrayDeque<>();
        int nextEnqueue = 0;

        for (int wanted : output) {
            while ((q.isEmpty() || q.peek() != wanted) && nextEnqueue <= 9) {
                q.add(nextEnqueue++);
            }

            if (q.isEmpty() || q.peek() != wanted) {
                return false;
            }
            q.remove();
        }
        return true;
    }

    public static void main(String[] args) {
        int[][] tests = {
            {0,1,2,3,4,5,6,7,8,9},
            {4,6,8,7,5,3,2,9,0,1},
            {2,5,6,7,4,8,9,3,1,0},
            {4,3,2,1,0,5,6,7,8,9}
        };

        char c = 'a';
        for (int[] test : tests) {
            System.out.println(c++ + ": " + isPossible(test));
        }
    }
}
