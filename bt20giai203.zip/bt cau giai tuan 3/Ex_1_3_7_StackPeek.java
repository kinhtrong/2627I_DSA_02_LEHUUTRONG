import java.util.*;

public class Ex_1_3_7_StackPeek {
    static class StackWithPeek<Item> {
        private final Deque<Item> stack = new ArrayDeque<>();

        public void push(Item item) {
            stack.push(item);
        }

        public Item pop() {
            return stack.pop();
        }

        public Item peek() {
            if (stack.isEmpty()) throw new NoSuchElementException("Stack is empty");
            return stack.peek();
        }

        public boolean isEmpty() {
            return stack.isEmpty();
        }
    }

    public static void main(String[] args) {
        StackWithPeek<Integer> stack = new StackWithPeek<>();
        stack.push(10);
        stack.push(20);

        System.out.println("peek = " + stack.peek());
        System.out.println("pop  = " + stack.pop());
        System.out.println("peek = " + stack.peek());
    }
}
