public class Ex_1_2_29_ColorConversion {
    /*
     * Input command line:
     * R G B, mỗi giá trị nguyên từ 0 đến 255.
     *
     * Output: C M Y K theo công thức RGB -> CMYK.
     */
    public static void main(String[] args) {
        if (args.length != 3) {
            System.out.println("Usage: java Ex_1_2_29_ColorConversion R G B");
            return;
        }

        int r = Integer.parseInt(args[0]);
        int g = Integer.parseInt(args[1]);
        int b = Integer.parseInt(args[2]);

        double R = r / 255.0;
        double G = g / 255.0;
        double B = b / 255.0;

        double w = Math.max(R, Math.max(G, B));

        double c, m, y, k;
        if (w == 0.0) {
            c = m = y = 0.0;
            k = 1.0;
        } else {
            k = 1.0 - w;
            c = (w - R) / w;
            m = (w - G) / w;
            y = (w - B) / w;
        }

        System.out.printf("C = %.4f%n", c);
        System.out.printf("M = %.4f%n", m);
        System.out.printf("Y = %.4f%n", y);
        System.out.printf("K = %.4f%n", k);
    }
}
