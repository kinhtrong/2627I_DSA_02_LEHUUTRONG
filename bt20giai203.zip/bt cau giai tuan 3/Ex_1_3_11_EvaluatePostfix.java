import java.util.*;

public class Ex_1_3_11_EvaluatePostfix {
    private static boolean isOperator(String s) {
        return s.equals("+") || s.equals("-") ||
               s.equals("*") || s.equals("/");
    }

    public static double evaluate(String expression) {
        Deque<Double> stack = new ArrayDeque<>();
        StringTokenizer st = new StringTokenizer(expression);

        while (st.hasMoreTokens()) {
            String token = st.nextToken();

            if (!isOperator(token)) {
                stack.push(Double.parseDouble(token));
            } else {
                if (stack.size() < 2) throw new IllegalArgumentException("Invalid postfix");
                double b = stack.pop();
                double a = stack.pop();

                switch (token) {
                    case "+": stack.push(a + b); break;
                    case "-": stack.push(a - b); break;
                    case "*": stack.push(a * b); break;
                    case "/": stack.push(a / b); break;
                    default: throw new IllegalArgumentException("Unknown operator");
                }
            }
        }

        if (stack.size() != 1) throw new IllegalArgumentException("Invalid postfix");
        return stack.pop();
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String input = sc.useDelimiter("\\A").hasNext() ? sc.next() : "";
        System.out.println(evaluate(input));
    }
}
