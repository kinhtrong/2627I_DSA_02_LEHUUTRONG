public class Bai3_BST_Insertion {
    static class Node {
        int data; Node left, right;
        Node(int data) { this.data = data; }
    }

    public static Node insert(Node root, int data) {
        if (root == null) return new Node(data);
        if (data < root.data) root.left = insert(root.left, data);
        else if (data > root.data) root.right = insert(root.right, data);
        return root;
    }

    public static Node insertIterative(Node root, int data) {
        Node added = new Node(data);
        if (root == null) return added;
        Node current = root, parent = null;
        while (current != null) {
            parent = current;
            if (data < current.data) current = current.left;
            else if (data > current.data) current = current.right;
            else return root;
        }
        if (data < parent.data) parent.left = added;
        else parent.right = added;
        return root;
    }

    public static void preorder(Node root) {
        if (root == null) return;
        System.out.print(root.data + " ");
        preorder(root.left);
        preorder(root.right);
    }

    public static void main(String[] args) {
        Node root = new Node(4);
        root.left = new Node(2); root.right = new Node(7);
        root.left.left = new Node(1); root.left.right = new Node(3);
        root = insert(root, 6);
        preorder(root);
    }
}
