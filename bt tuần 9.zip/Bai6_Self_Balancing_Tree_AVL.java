public class Bai6_Self_Balancing_Tree_AVL {
    static class Node {
        int val; Node left, right; int ht;
        Node(int val) { this.val = val; this.ht = 0; }
    }

    private static int height(Node n) { return n == null ? -1 : n.ht; }
    private static int max(int a, int b) { return a > b ? a : b; }
    private static int balance(Node n) {
        return n == null ? 0 : height(n.left) - height(n.right);
    }
    private static void updateHeight(Node n) {
        n.ht = 1 + max(height(n.left), height(n.right));
    }

    private static Node rotateRight(Node y) {
        Node x = y.left;
        Node middle = x.right;
        x.right = y;
        y.left = middle;
        updateHeight(y);
        updateHeight(x);
        return x;
    }

    private static Node rotateLeft(Node x) {
        Node y = x.right;
        Node middle = y.left;
        y.left = x;
        x.right = middle;
        updateHeight(x);
        updateHeight(y);
        return y;
    }

    public static Node insert(Node root, int value) {
        if (root == null) return new Node(value);

        if (value < root.val) root.left = insert(root.left, value);
        else if (value > root.val) root.right = insert(root.right, value);
        else return root;

        updateHeight(root);
        int bf = balance(root);

        if (bf > 1 && value < root.left.val) return rotateRight(root);
        if (bf < -1 && value > root.right.val) return rotateLeft(root);

        if (bf > 1 && value > root.left.val) {
            root.left = rotateLeft(root.left);
            return rotateRight(root);
        }

        if (bf < -1 && value < root.right.val) {
            root.right = rotateRight(root.right);
            return rotateLeft(root);
        }

        return root;
    }

    public static void preorder(Node root) {
        if (root == null) return;
        System.out.print(root.val + " ");
        preorder(root.left);
        preorder(root.right);
    }

    public static void main(String[] args) {
        Node root = new Node(3);
        root.left = new Node(2);
        root.right = new Node(4);
        root.right.right = new Node(5);
        root.right.ht = 1;
        root.ht = 2;
        root = insert(root, 6);
        preorder(root);
    }
}
