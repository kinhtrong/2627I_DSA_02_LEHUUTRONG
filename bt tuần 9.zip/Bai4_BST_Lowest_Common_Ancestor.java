public class Bai4_BST_Lowest_Common_Ancestor {
    static class Node {
        int data; Node left, right;
        Node(int data) { this.data = data; }
    }

    public static Node lca(Node root, int v1, int v2) {
        if (root == null) return null;
        if (v1 < root.data && v2 < root.data) return lca(root.left, v1, v2);
        if (v1 > root.data && v2 > root.data) return lca(root.right, v1, v2);
        return root;
    }

    public static Node insert(Node root, int data) {
        if (root == null) return new Node(data);
        if (data < root.data) root.left = insert(root.left, data);
        else if (data > root.data) root.right = insert(root.right, data);
        return root;
    }

    public static void main(String[] args) {
        int[] values = {4, 2, 3, 1, 7, 6};
        Node root = null;
        for (int value : values) root = insert(root, value);
        System.out.println(lca(root, 1, 7).data);
    }
}
