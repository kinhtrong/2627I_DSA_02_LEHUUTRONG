public class Bai5_Is_This_a_Binary_Search_Tree {
    static class Node {
        int data; Node left, right;
        Node(int data) { this.data = data; }
    }

    public static boolean checkBST(Node root) {
        return checkBST(root, Long.MIN_VALUE, Long.MAX_VALUE);
    }

    private static boolean checkBST(Node node, long min, long max) {
        if (node == null) return true;
        if (node.data <= min || node.data >= max) return false;
        return checkBST(node.left, min, node.data)
            && checkBST(node.right, node.data, max);
    }

    public static void main(String[] args) {
        Node root = new Node(4);
        root.left = new Node(2); root.right = new Node(6);
        root.left.left = new Node(1); root.left.right = new Node(3);
        System.out.println(checkBST(root) ? "Yes" : "No");
    }
}
