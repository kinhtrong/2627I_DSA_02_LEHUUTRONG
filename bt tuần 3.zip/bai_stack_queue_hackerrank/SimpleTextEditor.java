import java.io.*;
import java.util.*;

public class SimpleTextEditor {
    static class Operation {
        int type;
        String value;
        Operation(int type, String value) { this.type = type; this.value = value; }
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int q = Integer.parseInt(br.readLine().trim());
        StringBuilder text = new StringBuilder();
        Stack<Operation> history = new Stack<>();
        StringBuilder out = new StringBuilder();

        for (int i = 0; i < q; i++) {
            StringTokenizer st = new StringTokenizer(br.readLine());
            int type = Integer.parseInt(st.nextToken());

            if (type == 1) {
                String s = st.nextToken();
                history.push(new Operation(1, s));
                text.append(s);
            } else if (type == 2) {
                int k = Integer.parseInt(st.nextToken());
                String deleted = text.substring(text.length() - k);
                history.push(new Operation(2, deleted));
                text.delete(text.length() - k, text.length());
            } else if (type == 3) {
                int k = Integer.parseInt(st.nextToken());
                out.append(text.charAt(k - 1)).append('\n');
            } else if (type == 4) {
                Operation last = history.pop();
                if (last.type == 1) {
                    text.delete(text.length() - last.value.length(), text.length());
                } else {
                    text.append(last.value);
                }
            }
        }
        System.out.print(out);
    }
}
