import java.io.*;
import java.util.*;

public class QueueUsingTwoStacks {
    static class MyQueue {
        private final Stack<Integer> stackIn = new Stack<>();
        private final Stack<Integer> stackOut = new Stack<>();

        void enqueue(int x) { stackIn.push(x); }

        private void moveIfNeeded() {
            if (stackOut.isEmpty()) {
                while (!stackIn.isEmpty()) stackOut.push(stackIn.pop());
            }
        }

        int dequeue() { moveIfNeeded(); return stackOut.pop(); }
        int peek() { moveIfNeeded(); return stackOut.peek(); }
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int q = Integer.parseInt(br.readLine().trim());
        MyQueue queue = new MyQueue();
        StringBuilder out = new StringBuilder();

        for (int i = 0; i < q; i++) {
            StringTokenizer st = new StringTokenizer(br.readLine());
            int type = Integer.parseInt(st.nextToken());
            if (type == 1) queue.enqueue(Integer.parseInt(st.nextToken()));
            else if (type == 2) queue.dequeue();
            else if (type == 3) out.append(queue.peek()).append('\n');
        }
        System.out.print(out);
    }
}
