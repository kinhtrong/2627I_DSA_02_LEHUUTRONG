import java.io.*;
import java.util.*;

public class EqualStacks {
    static int equalStacks(int[] h1, int[] h2, int[] h3) {
        int sum1 = 0, sum2 = 0, sum3 = 0;
        for (int x : h1) sum1 += x;
        for (int x : h2) sum2 += x;
        for (int x : h3) sum3 += x;

        int i = 0, j = 0, k = 0;
        while (true) {
            if (sum1 == sum2 && sum2 == sum3) return sum1;
            if (sum1 >= sum2 && sum1 >= sum3) sum1 -= h1[i++];
            else if (sum2 >= sum1 && sum2 >= sum3) sum2 -= h2[j++];
            else sum3 -= h3[k++];
        }
    }

    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        StringTokenizer st = new StringTokenizer(br.readLine());
        int n1 = Integer.parseInt(st.nextToken());
        int n2 = Integer.parseInt(st.nextToken());
        int n3 = Integer.parseInt(st.nextToken());
        int[] h1 = new int[n1], h2 = new int[n2], h3 = new int[n3];

        st = new StringTokenizer(br.readLine());
        for (int i = 0; i < n1; i++) h1[i] = Integer.parseInt(st.nextToken());
        st = new StringTokenizer(br.readLine());
        for (int i = 0; i < n2; i++) h2[i] = Integer.parseInt(st.nextToken());
        st = new StringTokenizer(br.readLine());
        for (int i = 0; i < n3; i++) h3[i] = Integer.parseInt(st.nextToken());

        System.out.println(equalStacks(h1, h2, h3));
    }
}
