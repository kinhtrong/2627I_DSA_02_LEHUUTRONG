import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class MissingNumbers {
    private static final int METHOD = 1;

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int[] a = new int[n];
        for (int i = 0; i < n; i++) {
            a[i] = sc.nextInt();
        }

        int m = sc.nextInt();
        int[] b = new int[m];
        for (int i = 0; i < m; i++) {
            b[i] = sc.nextInt();
        }

        List<Integer> result;
        if (METHOD == 1) {
            result = missingByHashTable(a, b);
        } else if (METHOD == 2) {
            result = missingBySorting(a, b);
        } else if (METHOD == 3) {
            result = missingByCountingSort(a, b);
        } else {
            throw new IllegalStateException("METHOD must be 1, 2, or 3.");
        }

        printResult(result);
        sc.close();
    }

    private static List<Integer> missingByHashTable(int[] a, int[] b) {
        Map<Integer, Integer> frequency = new HashMap<>();

        for (int value : a) {
            frequency.put(value, frequency.getOrDefault(value, 0) - 1);
        }
        for (int value : b) {
            frequency.put(value, frequency.getOrDefault(value, 0) + 1);
        }

        List<Integer> result = new ArrayList<>();
        for (Map.Entry<Integer, Integer> entry : frequency.entrySet()) {
            if (entry.getValue() > 0) {
                result.add(entry.getKey());
            }
        }

        result.sort(Integer::compareTo);
        return result;
    }

    private static List<Integer> missingBySorting(int[] a, int[] b) {
        int[] sortedA = Arrays.copyOf(a, a.length);
        int[] sortedB = Arrays.copyOf(b, b.length);
        Arrays.sort(sortedA);
        Arrays.sort(sortedB);

        List<Integer> result = new ArrayList<>();
        int i = 0;
        int j = 0;

        while (j < sortedB.length) {
            int value = sortedB[j];
            int countB = 0;
            int countA = 0;

            while (j < sortedB.length && sortedB[j] == value) {
                countB++;
                j++;
            }

            while (i < sortedA.length && sortedA[i] < value) {
                i++;
            }

            while (i < sortedA.length && sortedA[i] == value) {
                countA++;
                i++;
            }

            if (countB > countA) {
                result.add(value);
            }
        }

        return result;
    }

    private static List<Integer> missingByCountingSort(int[] a, int[] b) {
        List<Integer> result = new ArrayList<>();
        if (b.length == 0) {
            return result;
        }

        int min = b[0];
        int max = b[0];
        for (int value : b) {
            if (value < min) {
                min = value;
            }
            if (value > max) {
                max = value;
            }
        }

        int range = (int) ((long) max - min + 1);
        int[] countA = new int[range];
        int[] countB = new int[range];

        for (int value : a) {
            if (value >= min && value <= max) {
                countA[(int) ((long) value - min)]++;
            }
        }
        for (int value : b) {
            countB[(int) ((long) value - min)]++;
        }

        for (int index = 0; index < range; index++) {
            if (countB[index] > countA[index]) {
                result.add((int) ((long) min + index));
            }
        }

        return result;
    }

    private static void printResult(List<Integer> result) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < result.size(); i++) {
            if (i > 0) {
                sb.append(' ');
            }
            sb.append(result.get(i));
        }
        System.out.println(sb);
    }
}
