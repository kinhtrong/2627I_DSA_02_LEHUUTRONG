import java.util.Comparator;
import java.util.Locale;
import java.util.Scanner;
import java.util.TreeSet;

public class FindRunningMedian {
    private static class Entry {
        int value;
        int order;

        Entry(int value, int order) {
            this.value = value;
            this.order = order;
        }
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        Comparator<Entry> comparator = (x, y) -> {
            int result = Integer.compare(x.value, y.value);
            if (result != 0) {
                return result;
            }
            return Integer.compare(x.order, y.order);
        };

        TreeSet<Entry> tree = new TreeSet<>(comparator);
        Entry median = null;

        for (int i = 0; i < n; i++) {
            Entry current = new Entry(sc.nextInt(), i);
            int oldSize = tree.size();

            Entry oldUpperMedian = null;
            if (oldSize > 0 && oldSize % 2 == 0) {
                oldUpperMedian = tree.higher(median);
            }

            tree.add(current);

            if (oldSize == 0) {
                median = current;
            } else if (oldSize % 2 == 1) {
                if (comparator.compare(current, median) < 0) {
                    median = tree.lower(median);
                }
            } else {
                if (comparator.compare(current, median) < 0) {
                    median = median;
                } else if (comparator.compare(current, oldUpperMedian) > 0) {
                    median = oldUpperMedian;
                } else {
                    median = current;
                }
            }

            if (tree.size() % 2 == 1) {
                System.out.printf(Locale.US, "%.1f%n", (double) median.value);
            } else {
                Entry upperMedian = tree.higher(median);
                double result = ((long) median.value + upperMedian.value) / 2.0;
                System.out.printf(Locale.US, "%.1f%n", result);
            }
        }

        sc.close();
    }
}
