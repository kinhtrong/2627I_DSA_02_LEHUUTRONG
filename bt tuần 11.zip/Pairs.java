import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class Pairs {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        long k = Math.abs(sc.nextLong());

        Map<Long, Integer> frequency = new HashMap<>();
        for (int i = 0; i < n; i++) {
            long value = sc.nextLong();
            frequency.put(value, frequency.getOrDefault(value, 0) + 1);
        }

        long answer = 0;

        if (k == 0) {
            for (int count : frequency.values()) {
                answer += (long) count * (count - 1) / 2;
            }
        } else {
            Set<Long> values = new HashSet<>(frequency.keySet());
            for (long value : values) {
                if (values.contains(value + k)) {
                    answer++;
                }
            }
        }

        System.out.println(answer);
        sc.close();
    }
}
